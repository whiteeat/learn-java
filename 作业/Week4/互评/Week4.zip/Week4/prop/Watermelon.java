package prop;

public class Watermelon {

    private final int size;

    public int getSize() {
        return size;
    }

    public Watermelon(int size) {
        this.size = size;
    }

}
