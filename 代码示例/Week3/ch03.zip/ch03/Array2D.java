class Array2D 
{
	public static void main(String[] args) 
	{
		int [][] a = {{1,2},{3,4,0},{5,6}};
		System.out.println(a[0].length);
	}
}
