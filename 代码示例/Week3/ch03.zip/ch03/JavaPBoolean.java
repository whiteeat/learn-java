class JavaPBoolean
{
	public static void main(String[] args) 
	{
		boolean a=true;
		boolean b=false;
		System.out.println(a+","+b);
	}
}
