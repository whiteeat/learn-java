class JavaPAplusplus
{
	public static void main(String[] args) 
	{
		int a=2;
		int b= a++ + ++a;
		System.out.println(b);
	}
}
