public class A {
   public static void main(String [] args) {
      String ja = "Ja";
      String va = "va";
      String java1 = ja + va;
      String java = "Java";
      System.out.println("java.equals(java1)? " + java.equals(java1));  //true 
      System.out.println("java = = java1? " + (java == java1)); // false��������
	}
}
