class JavaPConstructor
{
	int a=2000;
	JavaPConstructor(){
		this.a=3000;
	}
}