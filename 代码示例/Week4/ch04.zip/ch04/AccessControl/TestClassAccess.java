package p3;

class TestClassAccess
{
	public static void main(String[] args) 
	{
		p1.Original o; //ok!
		p2.Derived  o2; // ���ܴ�ȡ
	}
}
